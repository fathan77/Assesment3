package org.d3if0154.assesment3.model

data class User(
    val name: String = "",
    val email: String = "",
    val photoUrl: String = ""
)