package org.d3if0154.assesment3.model

data class OpStatus(
    var status: String,
    var message: String?
)
