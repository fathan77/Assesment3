package org.d3if0154.assesment3.model

data class Film(
    val id: Long,
    val namaFilm: String,
    val namaPembuat: String,
    val imageId: String,
    val mine: Int

)
